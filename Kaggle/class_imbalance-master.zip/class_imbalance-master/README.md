# Practical tips for class imbalance in binary classification
#### _Zichen Wang_

A [blog post](https://medium.com/@wangzc921/practical-tips-for-class-imbalance-in-binary-classification-6ee29bcdb8a7?source=friends_link&sk=16c43640eab3817a8de3cb15eedb181a) was writen based on this tutorial. 

## Requirements
To run the notebook, install modules on Python2.7 in [requirements.txt](https://github.com/wangz10/class_imbalance/blob/master/requirements.txt).

`
pip install -r requirements.txt
`
